##Logistic Regression via Hastings-Metropolis
#Generate a fake data sample for test
# ptm = proc.time()
inputArgs = commandArgs(trailingOnly = T)
# inputArgs = c(5000,10000, -1.5,1.5,.1)
burnIn = inputArgs[1]
iterations = as.numeric(inputArgs[2])
startvalue = c(as.numeric(inputArgs[3:5]))
B0Actual = -2
B1Actual = 1
ScaleActual = .05
BetaShape2 = (1 - ScaleActual)/ScaleActual #Since E[x] = a/(a+b) for B.D. and we assume a = 1
sd = ScaleActual/sqrt(pi^2/3)
x = seq(-10,15,by = 0.25)
y = exp(B1Actual*x+B0Actual)/(1+exp(B1Actual*x+B0Actual)) + rlogis(length(x),0,ScaleActual)
B0PropSD = .8
B1PropSD = .4
BetaShape2Prop = 19 
# iterations = 10000
# startvalue = c(-1.5,1.5,.1)
plot(x,y)
#Try to find a solution to the following: y = exp(B1*x + B0)/(1+exp(B1*x+B0)) + Logistic(0,scale)
#The error is logistically distributed with a scale parameter which is approximately beta distributed.
#The scale parameter is directly proportional to the standard deviation by a factor of sqrt(pi^2/3).
#First compute likelihood function 
likelihood = function(parameters){
  B0 = parameters[1]
  B1 = parameters[2]
  scale = parameters[3]
  #x is the independent variable in the data set
  probcurve = exp(B1*x + B0)/(1+exp(B1*x+B0)) + rlogis(1, location = 0,scale = scale)
  #y is the dependent variable in the data set. Here we assume the likelihoods B1,B0 are normally distributed.
  #compute individual log likelihoods
  loglikelihoods = dnorm(y,mean = probcurve, sd = scale, log = T)
  #sum log likelihoods and return total 
  return(sum(loglikelihoods))
}
#Construct a prior log distribution 
prior = function(parameters){
  B0 = parameters[1]
  B1 = parameters[2]
  scale = parameters[3]
  #Sample from log distributions for the parameters
  B0prior = dnorm(B0, sd = B0PropSD, log = T)
  B1prior = dnorm(B1, sd = B1PropSD, log = T)
  #The error in logistic regression is logistically distributed. If X~U(0,1) then X~Logistic(mu,beta)
  scaleprior = dbeta(scale, 1,BetaShape2, log = T)
  #Return sum of log probabilities
  return(B1prior + B0prior+ scaleprior)
}
#Calculate posterior distribution
posterior = function(parameters){
  return(likelihood(parameters) + prior(parameters))
}
#Proposal distribution: narrow proposal = high rejectance prob, slower but more stable convergence
proposalfunction = function(parameters){
  return(c(rnorm(2,mean = c(parameters[1],parameters[2]), sd = c(B0PropSD,B1PropSD)),rbeta(1,1,BetaShape2Prop)))
}

run_MCMC = function(startValue,iterations){
  #Create chain matrix
  chain = array(dim = c(iterations+1,3))
  chain[1,] = startValue
  for(i in 1:iterations){
    #sample from proposal distribution for i-th chain iteration
    proposal = proposalfunction(chain[i,])
    #Calculate MH acceptance criterion
    probab = exp(posterior(proposal) - posterior(chain[i,]))
    if (runif(1) < probab){
      chain[i+1,] = proposal
    }else{
      chain[i+1,] = chain[i,]
    }
    # print(i)
  }
  return(chain)
}

chain = run_MCMC(startvalue, iterations)

#Calculate average acceptance rate
# burnIn = iterations/2
acceptance = 1-mean(duplicated(chain[-(1:burnIn),]))

calcPVal = function(actual,parameterindex){
  if((actual - chain[iterations,parameterindex]) > 0){
    return(length(subset(chain[,parameterindex], chain[,parameterindex] > actual))/iterations)
  }else{
    return(length(subset(chain[,parameterindex], chain[,parameterindex] < actual))/iterations)
  }
}
# proc.time() - ptm
graphHM = function(){par(mfrow = c(2,3))
  hist(chain[-(1:burnIn),1],nclass=30, , main="Posterior of B0", xlab="True value = red line" )
  abline(v = mean(chain[-(1:burnIn),1]))
  abline(v = B0Actual, col="red" )
  hist(chain[-(1:burnIn),2],nclass=30, main="Posterior of B1", xlab="True value = red line")
  abline(v = mean(chain[-(1:burnIn),2]))
  abline(v = B1Actual, col="red" )
  hist(chain[-(1:burnIn),3],nclass=30, main="Posterior of Scale", xlab="True value = red line")
  abline(v = mean(chain[-(1:burnIn),3]) )
  abline(v = ScaleActual, col="red" )
  plot(chain[-(1:burnIn),1], type = "l", xlab="True value = red line" , main = "Chain values of B0", )
  abline(h = B0Actual, col="red" )
  plot(chain[-(1:burnIn),2], type = "l", xlab="True value = red line" , main = "Chain values of B1", )
  abline(h = B1Actual, col="red" )
  plot(chain[-(1:burnIn),3], type = "l", xlab="True value = red line" , main = "Chain values of Scale", )
  abline(h = ScaleActual, col="red" )
}
jpeg(file = "/Users/bradleym3/Documents/javaworkspace/Final_Project_GUI/images/graphs.jpg", quality = 1)
graphHM()
dev.off()
write.csv(chain,"~/Documents/Projects/FakeData.csv")
# print(inputArgs)
print(c(acceptance, calcPVal(-2,1),calcPVal(1,2),calcPVal(0.05,3)))