#Acceptance Optimization Monte Carlo
library(parallel)
library(doParallel)
library(foreach)

B1range = 20 #B1 searching from 0.01 to 1.5
B0range =  20 #B0 searching from 0.005 to 1 by 0.005
n = B0range * B1range

#Script-start
time = proc.time()
no_cores = detectCores() - 1
cl = makeCluster(no_cores)
registerDoParallel(cl,cores = no_cores) #find no. cores, create cluster, register cluster
acceptances = foreach(i = 1:B0range, .combine = c)%dopar%{
  B0PropSD = 0.002*i
  for(j in 1:B1range){
    B1PropSD = 0.05*j
    chain = run_MCMC(startvalue,iterations)
    # print(chain[iterations,])
   -log(1-mean(duplicated(chain[-(1:burnIn),])))
  }
}
stopCluster(cl)
proc.time() - time
#Time for 100 iterations no parallelization: 56.238s
#Time for 100 iterations inner loop parallelized: 14.604s
#Time for 100 iterations outer loop parallelized: 14.315s

predictedtime = function(format){
  timeperiteration = 14.315/100
  if(missing(format)){
    n * timeperiteration / 3600
  }else if(format == 'minutes'){
    n * timeperiteration / 60
  }
}