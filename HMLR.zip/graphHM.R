#HM Graphing

graphHM = function(){par(mfrow = c(2,3))
hist(chain[-(1:burnIn),1],nclass=30, , main="Posterior of B0", xlab="True value = red line" )
abline(v = mean(chain[-(1:burnIn),1]))
abline(v = B0Actual, col="red" )
hist(chain[-(1:burnIn),2],nclass=30, main="Posterior of B1", xlab="True value = red line")
abline(v = mean(chain[-(1:burnIn),2]))
abline(v = B1Actual, col="red" )
hist(chain[-(1:burnIn),3],nclass=30, main="Posterior of Scale", xlab="True value = red line")
abline(v = mean(chain[-(1:burnIn),3]) )
abline(v = ScaleActual, col="red" )
plot(chain[-(1:burnIn),1], type = "l", xlab="True value = red line" , main = "Chain values of B0", )
abline(h = B0Actual, col="red" )
plot(chain[-(1:burnIn),2], type = "l", xlab="True value = red line" , main = "Chain values of B1", )
abline(h = B1Actual, col="red" )
plot(chain[-(1:burnIn),3], type = "l", xlab="True value = red line" , main = "Chain values of Scale", )
abline(h = ScaleActual, col="red" )
}