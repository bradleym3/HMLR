#BurnIn Period tests
library(doParallel)
no_cores = detectCores() - 1
cl = makeCluster(no_cores)
registerDoParallel(cl)
burnaccepts = rep(0,7000)
foreach(burnIn = 0:7000, .combine = c) %do% {
  burnIn
}
stopCluster(cl)