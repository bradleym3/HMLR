calcPVal = function(actual,parameterindex){
  if((actual - chain[iterations,parameterindex]) > 0){
    return(length(subset(chain[,parameterindex], chain[,parameterindex] > actual))/iterations)
  }else{
    return(length(subset(chain[,parameterindex], chain[,parameterindex] < actual))/iterations)
  }
}